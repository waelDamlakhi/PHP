-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 13 سبتمبر 2020 الساعة 14:18
-- إصدار الخادم: 8.0.18
-- PHP Version: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `real_estate_store`
--
CREATE DATABASE IF NOT EXISTS `real_estate_store` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `real_estate_store`;

-- --------------------------------------------------------

--
-- بنية الجدول `apartments`
--

DROP TABLE IF EXISTS `apartments`;
CREATE TABLE IF NOT EXISTS `apartments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_of_cladding` varchar(255) NOT NULL,
  `total_num_of_room` int(11) NOT NULL,
  `num_of bedrooms` int(11) NOT NULL,
  `num_of_bathrooms` int(11) NOT NULL,
  `num_of_kitchens` int(11) NOT NULL,
  `total_area` int(11) NOT NULL,
  `Apart_floor_num` int(11) NOT NULL,
  `num_of_building_floors` int(11) NOT NULL,
  `Apartment_view` varchar(255) NOT NULL,
  `brush_condition` varchar(255) NOT NULL,
  `other_accessories` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- بنية الجدول `building`
--

DROP TABLE IF EXISTS `building`;
CREATE TABLE IF NOT EXISTS `building` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `total_area` int(11) NOT NULL,
  `num_of_building_floors` int(11) NOT NULL,
  `num_of_apart_on_each_floor` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- بنية الجدول `building_details`
--

DROP TABLE IF EXISTS `building_details`;
CREATE TABLE IF NOT EXISTS `building_details` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `type_of_cladding` varchar(255) NOT NULL,
  `Property_type` varchar(255) NOT NULL,
  `property_area` int(11) NOT NULL,
  PRIMARY KEY (`content_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- بنية الجدول `real_estate`
--

DROP TABLE IF EXISTS `real_estate`;
CREATE TABLE IF NOT EXISTS `real_estate` (
  `Re_id` int(11) NOT NULL AUTO_INCREMENT,
  `Account_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `Property_type` varchar(255) NOT NULL,
  `Investment_type` varchar(255) NOT NULL,
  `Governorate` varchar(255) NOT NULL,
  `Region` varchar(255) NOT NULL,
  `street_name` varchar(255) NOT NULL,
  `Special_place` varchar(255) NOT NULL,
  `Main_Img` varchar(255) NOT NULL,
  `Sec_Img` varchar(255) NOT NULL,
  `owner_type` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `publishing_time` date NOT NULL,
  PRIMARY KEY (`Re_id`),
  KEY `Account_id` (`Account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- بنية الجدول `shops`
--

DROP TABLE IF EXISTS `shops`;
CREATE TABLE IF NOT EXISTS `shops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_of_cladding` varchar(255) NOT NULL,
  `total_area` int(11) NOT NULL,
  `num_of_interfaces` int(11) NOT NULL,
  `total_length_of_facades` int(11) NOT NULL,
  `Accessories` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- بنية الجدول `user_account`
--

DROP TABLE IF EXISTS `user_account`;
CREATE TABLE IF NOT EXISTS `user_account` (
  `Account_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`Account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `user_account`
--

INSERT INTO `user_account` (`Account_id`, `fullname`, `username`, `email`, `phone`, `Password`) VALUES
(1, 'm w d', 'wael', 'mr.wael.mwd@gmail.com', '0991155638', '12345678');

-- --------------------------------------------------------

--
-- بنية الجدول `villa_or_farm`
--

DROP TABLE IF EXISTS `villa_or_farm`;
CREATE TABLE IF NOT EXISTS `villa_or_farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_of_cladding` varchar(255) NOT NULL,
  `total_land_area` int(11) NOT NULL,
  `Earth_type` varchar(255) NOT NULL,
  `building_area` int(11) NOT NULL,
  `num_of_building_floors` int(11) NOT NULL,
  `Accessories` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `building_details`
--
ALTER TABLE `building_details`
  ADD CONSTRAINT `building_details_ibfk_1` FOREIGN KEY (`id`) REFERENCES `building` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- القيود للجدول `real_estate`
--
ALTER TABLE `real_estate`
  ADD CONSTRAINT `real_estate_ibfk_1` FOREIGN KEY (`Account_id`) REFERENCES `user_account` (`Account_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
